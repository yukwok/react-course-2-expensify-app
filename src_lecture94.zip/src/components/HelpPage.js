import React from 'react';


const HelpPage = () => (
    <div>
       this is Help Page dash borad page.
    </div>
);

export default HelpPage;