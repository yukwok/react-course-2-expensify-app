import React from 'react';

const EditExpensePage = (props) => {

    return (
        <div>
           this is Edit ExpensePage dash borad page.
        </div>
    );

};


export default EditExpensePage;