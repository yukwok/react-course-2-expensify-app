import React from 'react';

const ExpenseDashboardPage = () => (
    <div>
       this is dash borad page.
    </div>
);

export default ExpenseDashboardPage;