import React from 'react';


const AddExpensePage = () => (
    <div>
       this is add ExpensePage dash borad page.
    </div>
);

export default AddExpensePage;
