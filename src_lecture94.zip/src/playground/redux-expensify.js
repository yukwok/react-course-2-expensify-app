import {  createStore, combineReducers } from 'redux';
import uuid from 'uuid';


// add expense
const addExpense = (
    {
        description= '',
        note = 'no notes',
        amount = 999999999,
        createdAt = 1997
    } = {}
) => (
      {
        type: 'ADD_EXPENSE',
        expense: {
            id: uuid(),
            description,
            note,
            amount,
            createdAt
        }
      }
     );
//Remove expense
const removeExpense = ({ id } = {}) => ({
    type: 'REMOVE_EXPENSE',
    id

});
//Edit expense
const editExpense = ( id, updates) => ({
    type: 'EDIT_EXPENSE',
    id,
    updates
});

// set text filter
const setTextFilter = ( text = '') => ({
  type: 'SET_TEXT_FILTER',
  text
});

//sort_by_date
//sort_by_amount
//set_start_date
//set_endDate


//expense reducer

const expensesReducerDefaultState = [{a:1}, {a:2}];

const expensesReducer = (state = expensesReducerDefaultState, action) => {
  switch (action.type) {
      case 'ADD_EXPENSE':
        return [...state, action.expense];
      case 'REMOVE_EXPENSE':
        return state.filter( ({ id }) => id !== action.id );
      case 'EDIT_EXPENSE':
        return state.map( (eachElement) => {
            if(eachElement.id === action.id){
                return {
                  ...eachElement,
                  ...action.updates    
                };
            } else {
                return eachElement;
            };
        });
        return
      default:
        return state;
  }
};

//filter reducer
const filterReducerDefaultState = {
    text: '',
    sortBy: 'date', 
    startDate: undefined,
    endDate: undefined
};
const filterReducer = ( state = filterReducerDefaultState, action ) => {
    switch (action.type) {
        case 'SET_TEXT_FILTER':
          return {
            ...state, text: action.text
          };
        default:
          return state;
    }      
};


//store creation

const store = createStore( 
  combineReducers(
    {
        expenses: expensesReducer,
        filters: filterReducer
    }
  ) 
);

store.subscribe( () => {
    console.log(store.getState());

});

const expenseOne = store.dispatch( addExpense({ description: 'Rent', amount: 100 }));
const expenseTwo = store.dispatch( addExpense({ description: 'coffoe', amount: 3 }));
const expenseThree = store.dispatch( addExpense({ description: 'Ice-cream', amount: 5 }));


store.dispatch( removeExpense( { id: expenseThree.expense.id }));
store.dispatch( addExpense() );

store.dispatch( editExpense( expenseOne.expense.id, {description: 'mai on rental'}));
store.dispatch( editExpense( expenseOne.expense.id, {amount: 6000 }));

store.dispatch( setTextFilter('mai on rental') );
store.dispatch( setTextFilter() );



const demoState = {
    expenses: [{
      id: 'poijasdfhwer',
      description: 'January Rent',
      note: 'This was the final payment for that address',
      amount: 54500,
      createdAt: 0
    }],
    filters: {
      text: 'rent',
      sortBy: 'amount', // date or amount
      startDate: undefined,
      endDate: undefined
    }
};

// const user = {
//     name: 'Jen',
//     age: 20
// };


// console.log( {...user, age: 100, location: "taipo", dshd:"56476854dyjff"} );

// const arraay = [1,2,3,4,5];

// console.log( [2244, ...arraay, 67]);