const address = [ ];


const [street = "1234", area = "tintin houe", city] = address;

console.log(`i am in ${street} of ${area}`);